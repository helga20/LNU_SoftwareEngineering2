﻿namespace TransactionManagement.UnitTests.ClassFixtures
{
    [CollectionDefinition("TransactionServiceCollectionFixture")]
    public class TransactionServiceCollectionFixture : ICollectionFixture<TransactionServiceClassFixture>
    {
    }
}
