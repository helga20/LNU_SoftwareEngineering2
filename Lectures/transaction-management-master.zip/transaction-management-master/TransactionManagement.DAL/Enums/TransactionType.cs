﻿namespace TransactionManagement.DAL.Enums
{
    public enum TransactionType
    {
        Withdrawal = 1,
        Deposit = 2
    }
}
